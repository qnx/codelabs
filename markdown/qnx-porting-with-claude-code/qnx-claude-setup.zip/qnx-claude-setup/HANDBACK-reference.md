# QNX Aports Porting System - Handback

Purpose: this document hands the system back to a fresh Claude (for example Claude in the browser) so it can write a Claude Code guide that hooks into this setup. It describes the architecture, the files, the environment, and the verified end-to-end workflow (image start, connect, pull Alpine source, local repo, build, fix, patch, validate, PR). Everything marked "verified" was proven with command output on 2026-06-18 against the live target. Everything else is labeled.

No em dashes are used anywhere in this system (hard rule). Use hyphens, commas, parentheses, or colons.

---

## 1. What the system is

Native QNX 8.0 aports porting. Alpine Linux packages are built FOR QNX by building them ON a QNX target with Alpine's `abuild`. There is no cross-compile: no SDP, no qcc/q++, no toolchain files. The Linux host only launches a QNX QEMU image and holds an SSH session; all edit/build/test work happens on the target.

The workflow is driven by Claude Code reading a structured skill hierarchy plus two bootstrap docs, so a session starts already knowing the rules, the target, and where prior knowledge lives.

## 2. Repo layout (on the Linux host, /home/emazzuca/claude)

- `CLAUDE.md` - session bootstrap, read first automatically. Universal rules + skill map.
- `TARGET.md` - the target: connection, auth, the one authoritative tree path, the on-target loop, and a living "facts worth keeping current" log. This is where target-specific and image-specific knowledge accrues.
- `.claude/skills/` - the 13-skill hierarchy (router + core + driver leaves). Claude Code discovers and loads these on demand.
- `projects/apks/` - per-port notes, one folder per package, each with a PROJECT-INDEX and a README changelog. `projects/PROJECT-INDEX-template.md` is the template.
- `run.sh` - launches the QEMU target (see section 5).
- `backup/` - staging leftovers and the two retired flat global skills, kept for reference.
- `~/.claude/settings.json` - user-level Claude Code config; now carries permission allow rules so the workflow runs without prompting (see section 9).

## 3. The skill hierarchy

Router, read first, then cascade:

```
qnx-porting (router + universal rules)
├── qnx-platform-facts        QNX 8.0 OS truths (syscalls, libc gaps, stack, macros, toolchain quirks)
├── alpine-qnx-porting        APKBUILD content mechanics (deps, pkgrel, Vala, somask, repo conventions)
├── qnx-apk-packaging         end-to-end port-to-PR workflow + validation gate + source acquisition + local repo
├── aports-patch-creation     patch workflow, format gate, BusyBox-patch no-fuzz rule
├── github-fork-workflow      fork/branch/PR conventions, SSH key, commit subjects, PR-reply style
└── qnx-driver-development    driver router (char-serial, i2c, spi, hid, usb, sensor-camera leaves)
```

Each skill has a focused job and points at the others. The router holds the universal rules. Per-port history lives in `projects/apks/<pkg>/`, not in the shared skills.

## 4. Universal rules (apply to every task)

1. Prove claims with command output before acting. Do not assert platform behavior, dependency state, or build results without the command that shows it.
2. Never create a patch from an untested change. Test in the unpacked tree with native build tools first; write the patch only after the change is confirmed working.
3. The human runs all git operations. The agent edits and builds; it never commits or pushes.
4. Native aports builds only (abuild on the target). No cross-compile.
5. No em dashes in any output or file.
6. Record new confirmed facts back into the right skill the moment they are proven.
7. Capture friction as you go (master rule): anything that slows a session, breaks, or could be faster becomes a permanent skill/TARGET.md/settings update immediately, routed to where the next session will look for it.

## 5. Environment and how the image starts (verified)

`run.sh` launches the target with `qemu-system-x86_64`, KVM enabled, 16G RAM, the disk image `~/qnx-qemu/x86_64-desktop-qemu-uefi-2026-01-06.img`, UEFI via OVMF, an SDL/GL display, and crucially a user-net forward: host TCP 2227 to guest 22.

Verified host facts: `qemu-system-x86_64` and `sshpass` present, `/dev/kvm` available, OVMF at `/usr/share/OVMF/OVMF_CODE.fd`, the image exists (~215 GB sparse). The QEMU process is usually already running and bound to 2227 before a session starts (it was launched from `~/qnx-qemu`, not from the repo dir, so its relative `./OVMF_VARS.fd` and image paths resolve there). Always check `ss -ltnp | grep 2227` before launching; do not start a second instance.

## 6. Connecting (verified)

```sh
sshpass -p everywhere ssh -p 2227 \
  -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR \
  qnx@localhost '<remote command>'
```

- User `qnx`, password `everywhere` (root SSH is rejected). This is a throwaway local dev image; the shared password is fine here, not a security model.
- Every target operation is a quoted argument to this one call. The remote command is opaque to the local Claude Code permission check, so a single `Bash(sshpass:*)` allow rule covers the entire on-target workflow with no per-command prompts.
- For sudo on the target: `printf '%s\n' everywhere | sudo -S <command>`.

Verified identity: `QNX localhost 8.0.0 ... x86pc QNX`, `uname -m` returns `x86pc` (not `x86_64`).

## 7. The target trees (verified, discovered live)

`$HOME` is `/var/home/qnx`. Several aports checkouts exist there and are NOT interchangeable:

| Path | Remote | Role |
| --- | --- | --- |
| `aports_checkin` | SSH (`git@github.com:emazzucabb/aports.git`) | AUTHORITATIVE clean checkin tree. PRs push from here. Branch per change. |
| `aports` | HTTPS | Large scratch/dev tree (branch `803`), lots of uncommitted WIP. Reference only. |
| `aports_lama_test` | SSH | Per-port proof ground (llama.cpp). |
| `aports_webkit` | HTTPS | WebKit memory-fix work. |

The tree is a fork of `qnx-ports/aports` (CODEOWNERS owner `@qnx-ports/aports-admin`; managers Cris and Yun). It is organized into `core` (84 packages, ~Alpine main) and `extra` (534 packages, ~Alpine community/testing). `claude_handoff.txt` in `$HOME` is a prior-session handoff (llama.cpp PR qnx-ports/aports#398).

## 8. End-to-end porting lifecycle (the guide backbone)

This is the spine a guide should teach. Each step has a skill that owns the detail.

1. Acquire the source (qnx-apk-packaging step 2). The Alpine aport is the reference at `https://gitlab.alpinelinux.org/alpine/aports` under `main/<pkg>` or `community/<pkg>`. Place or update the package dir under the matching `core/` or `extra/` path in the QNX tree. The APKBUILD `source=` points at the upstream release tarball; `abuild` downloads it on first build and caches under `/var/cache/distfiles`. So the actual upstream code is pulled by the build, not copied by hand. Verified sample: `spirv-headers` uses `source="$pkgname-$pkgver.tar.gz::https://github.com/KhronosGroup/SPIRV-Headers/archive/refs/tags/vulkan-sdk-$pkgver.tar.gz"`.
2. Adapt the APKBUILD for QNX (alpine-qnx-porting): dependency renames, `main->core`/`community->extra`, `pkgrel=0` reset, maintainer headers, subpackage splits, `somask` for private libs, Vala workarounds. Preserve inherited Alpine logic unless it is the actual QNX blocker.
3. Configure local repo resolution (qnx-apk-packaging step 5). A successful `abuild -r` writes packages to `/var/home/qnx/packages/<repo>/<arch>` (verified: `extra/x86_64`, including a signed `APKINDEX.tar.gz`). List local paths before remote repos in `/etc/apk/repositories`, then `sudo apk update`. Only `extra` is published locally on this image.
4. Build and iterate. Use `abuild -K` (keeps `src/`) and native build tools (cmake/ninja/meson/make) in the unpacked tree while iterating. Never `abuild -r` while iterating; it wipes `src/`. Verified: `abuild -r` of `spirv-headers` completed in ~6s and produced `spirv-headers-1.4.321.0-r0.apk`.
5. Hit a platform wall? Go to qnx-platform-facts: sockets in `libsocket` (`-lsocket`), regex in `libregex` (`-lregex`), small default stack (size it in linker flags), `O_DIRECTORY` required for directory fds, `sysconf(_SC_PHYS_PAGES)` returns -1, `CMAKE_SYSTEM_PROCESSOR` is `unknown` (use `uname -m`), `PATH_MAX` in `<limits.h>`, gate QNX code on `__QNX__`.
6. Fix via patches (aports-patch-creation). Test the change first, then create the patch, fix the header to `a/`...`b/` form, add to `source=`, `abuild checksum`. QNX uses BusyBox `patch` with ZERO fuzz tolerance: a patch that applies on Alpine (GNU patch, fuzz 2) can reject on QNX. A matching sha512 proves the file is identical, NOT that it applies; verify with `abuild clean && abuild unpack`.
7. Validate (the gate): `abuild clean && abuild unpack` (no Hunk FAILED, no .rej), `abuild -r -c -K` (builds, tests pass, expected APKs), `find pkg -name '*.so*' | sort` (subpackage split), `git status` (only intended files).
8. PR (github-fork-workflow). One package per PR, dependencies before consumers. Commit subjects: `<repo>/<pkgname>: new aport` or `<repo>/<pkgname>: enable/fix build on QNX`. Push key `id_qnx_ed25519`. The human runs git.

## 9. Build-environment gotchas we hit and fixed (verified, target-specific)

These are the difference between "builds first try" and "builds fail mysteriously." All recorded in TARGET.md.

- Non-interactive abuild deps: `abuild -r` installs makedepends via `$SUDO_APK`, which cannot get root without a tty and fails `builddeps failed`. Fix: a wrapper `printf '#!/bin/sh\nprintf "%s\\n" everywhere | sudo -S apk "$@"\n' > /tmp/sudo-apk && chmod +x /tmp/sudo-apk`, then `SUDO_APK=/tmp/sudo-apk abuild -r`.
- Forbidden repos: `repo.qa.oss.qnx.com/8.0.3-rc1/qnx-{core,extra}` return HTTP 403, which apk counts as an error and aborts builddeps for ANY package. Commented out of `/etc/apk/repositories` (backup `.bak`). Working repos: local `extra` plus `repo.oss.qnx.com/8.0.3/{core,extra}`.
- Broken apk world: apk validates the whole installed world every transaction, so one file conflict fails every build with an opaque `1 error`. Diagnose with `apk fix 2>&1 | grep -i error`. We found `findutils` overwriting busybox's `/usr/bin/find`; fixed with `apk del findutils findutils-locate`. Also cleared 13 orphaned `.makedepends-*` virtuals from interrupted builds.
- Permissions made permanent: `~/.claude/settings.json` now allows `Bash(sshpass:*)` (covers all target work) plus read-only local helpers, so the workflow runs unattended in all sessions.
- Token-efficient pattern: log long builds to a file on the target and grep key lines back, do not stream full output. For multi-line remote commands, write a script via `ssh ... 'cat > /tmp/x.sh' <<'REMOTE'` then run it, to avoid nested-quote breakage.

## 10. What the guide should cover (suggested outline)

1. Mental model: native aports on a QNX target, not cross-compile.
2. Starting the image: `run.sh`, QEMU, the 2227 forward, checking it is up.
3. Connecting: the sshpass one-liner, the user/password, sudo pattern.
4. The trees: which one is authoritative and why, the core/extra split.
5. Acquiring a package from Alpine and placing it in the tree.
6. Local repo resolution and how the signed index is produced by abuild.
7. The build loop: iterate with `abuild -K`, validate with `abuild -r -c -K`.
8. Platform walls and their fixes (the qnx-platform-facts catalogue).
9. Patching the QNX way (BusyBox no-fuzz, the format gate).
10. The validation gate and PR conventions.
11. How the skill hierarchy + TARGET.md + per-port notes keep knowledge from being rediscovered, and the "capture friction" master rule.

## 11. Open items / things a future session should finish

- Driver leaf skills (spi, hid, usb, sensor-camera) are built out on demand from an internal reference; char-serial and i2c are the worked examples.
- The QA `8.0.3-rc1` repos returning 403 may be an auth/expiry issue on the user's side, not a permanent fact; revisit if access is restored.
- `/tmp/sudo-apk` is per-boot (ephemeral); TARGET.md documents how to recreate it. It holds the dev password in a world-readable temp file, acceptable only for this throwaway image.
- A full new-aport port IS done and is the best worked example for the guide: `json-c` 0.18 (pulled from Alpine `main`, adapted, built to `json-c` + `json-c-dev` APKs). The complete writeup, including the QNX deviations and an open `test_json_patch` SIGSEGV defect, is in `projects/apks/json-c/`. `spirv-headers` (header-only) remains the fast smoke test. The json-c port still has one open defect (`test_json_patch`), so it is packaged but not fully validated.

---

Source of truth for ongoing work stays in the repo: `CLAUDE.md`, `TARGET.md`, `.claude/skills/`, and `projects/apks/`. This handback is a snapshot to seed the guide; when facts change, update the skills and TARGET.md, not this file.

