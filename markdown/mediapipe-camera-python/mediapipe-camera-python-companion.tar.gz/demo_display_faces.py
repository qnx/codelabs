"""Live QNX camera to MediaPipe face detection to a PySDL2 window."""

from __future__ import annotations

import ctypes as c
import argparse
import gc
import os
import resource
import time
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "qnx")
os.environ.setdefault("PYSDL2_DLL_PATH", "/usr/lib")

import cv2
import mediapipe as mp
import numpy as np
import sdl2
from mediapipe.tasks import python as mpp
from mediapipe.tasks.python import vision

from qnx_camera_helper import QnxCamera


SCRIPT_DIR = Path(__file__).resolve().parent


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be a positive integer")
    return parsed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run MediaPipe face detection from Camera Module 3 and display it with SDL."
    )
    parser.add_argument(
        "--model",
        type=Path,
        default=SCRIPT_DIR / "models" / "blaze_face_short_range.tflite",
        help="MediaPipe Face Detector .tflite model",
    )
    parser.add_argument("--frames", type=positive_int, default=300, help="maximum frames to display")
    parser.add_argument("--width", type=positive_int, default=1152, help="display width")
    parser.add_argument("--height", type=positive_int, default=648, help="display height")
    parser.add_argument(
        "--renderer",
        choices=("opengles2", "software"),
        default="opengles2",
        help="exact SDL renderer; software is for diagnostics only",
    )
    parser.add_argument("--camera-unit", type=int, default=3, help="QNX Camera Library unit (default: 3 for QNX 8.0.5 QSTI, CM3 on DISP0)")
    parser.add_argument(
        "--frame-timeout",
        type=float,
        default=2.0,
        help="seconds to wait for each camera frame",
    )
    args = parser.parse_args()
    if args.frame_timeout <= 0:
        parser.error("--frame-timeout must be positive")
    return args


def sdl_error() -> str:
    error = sdl2.SDL_GetError()
    return error.decode(errors="replace") if error else ""


def setup_stage(name: str, operation):
    print(f"SETUP begin {name}", flush=True)
    start = time.perf_counter()
    result = operation()
    print(f"SETUP end {name} elapsed_ms={(time.perf_counter() - start) * 1000.0:.3f}", flush=True)
    return result


def create_renderer(window, requested_name: str):
    choices = {}
    for index in range(sdl2.SDL_GetNumRenderDrivers()):
        info = sdl2.SDL_RendererInfo()
        if sdl2.SDL_GetRenderDriverInfo(index, c.byref(info)) != 0:
            raise RuntimeError(f"SDL_GetRenderDriverInfo failed: {sdl_error()}")
        name = info.name.decode(errors="replace")
        choices[name] = index
        print(
            f"renderer available index={index} name={name} flags=0x{int(info.flags):x} "
            f"max_texture={info.max_texture_width}x{info.max_texture_height}",
            flush=True,
        )

    if requested_name not in ("opengles2", "software"):
        raise RuntimeError("renderer must be 'opengles2' or 'software'")
    if requested_name not in choices:
        raise RuntimeError(f"requested renderer {requested_name!r} is unavailable")

    requested_flags = (
        sdl2.SDL_RENDERER_ACCELERATED if requested_name == "opengles2" else sdl2.SDL_RENDERER_SOFTWARE
    )
    renderer = sdl2.SDL_CreateRenderer(window, choices[requested_name], requested_flags)
    if not renderer:
        raise RuntimeError(f"SDL_CreateRenderer failed: {sdl_error()}")

    selected = sdl2.SDL_RendererInfo()
    if sdl2.SDL_GetRendererInfo(renderer, c.byref(selected)) != 0:
        sdl2.SDL_DestroyRenderer(renderer)
        raise RuntimeError(f"SDL_GetRendererInfo failed: {sdl_error()}")
    selected_name = selected.name.decode(errors="replace")
    if selected_name != requested_name:
        sdl2.SDL_DestroyRenderer(renderer)
        raise RuntimeError(f"renderer mismatch: requested {requested_name}, selected {selected_name}")
    if requested_name == "opengles2" and not (selected.flags & sdl2.SDL_RENDERER_ACCELERATED):
        sdl2.SDL_DestroyRenderer(renderer)
        raise RuntimeError(f"renderer {selected_name} did not report SDL_RENDERER_ACCELERATED")
    if requested_name == "software" and not (selected.flags & sdl2.SDL_RENDERER_SOFTWARE):
        sdl2.SDL_DestroyRenderer(renderer)
        raise RuntimeError(f"renderer {selected_name} did not report SDL_RENDERER_SOFTWARE")

    print(
        f"renderer selected name={selected_name} flags=0x{int(selected.flags):x} "
        f"max_texture={selected.max_texture_width}x{selected.max_texture_height}",
        flush=True,
    )
    if selected_name == "opengles2":
        gles = c.CDLL("libGLESv2.so.1")
        gles.glGetString.restype = c.c_char_p
        gles.glGetString.argtypes = [c.c_uint]
        vendor = gles.glGetString(0x1F00)
        gl_renderer = gles.glGetString(0x1F01)
        version = gles.glGetString(0x1F02)
        print(
            f"GLES vendor={vendor.decode(errors='replace') if vendor else None!r} "
            f"renderer={gl_renderer.decode(errors='replace') if gl_renderer else None!r} "
            f"version={version.decode(errors='replace') if version else None!r}",
            flush=True,
        )
    return renderer


def main() -> None:
    args = parse_args()
    print(
        f"START frames={args.frames} display={args.width}x{args.height} renderer={args.renderer}",
        flush=True,
    )

    detector = None
    camera = QnxCamera(args.camera_unit)
    window = None
    renderer = None
    texture = None
    sdl_initialized = False
    try:
        detector = setup_stage(
            "FaceDetector.create",
            lambda: vision.FaceDetector.create_from_options(
                vision.FaceDetectorOptions(
                    base_options=mpp.BaseOptions(model_asset_path=str(args.model)),
                    min_detection_confidence=0.3,
                )
            ),
        )
        setup_stage("camera.open", camera.open)
        if setup_stage("SDL_Init", lambda: sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO)) != 0:
            raise RuntimeError(f"SDL_Init failed: {sdl2.SDL_GetError().decode()}")
        sdl_initialized = True
        window = setup_stage(
            "SDL_CreateWindow",
            lambda: sdl2.SDL_CreateWindow(
                b"QNX MediaPipe Camera",
                sdl2.SDL_WINDOWPOS_CENTERED,
                sdl2.SDL_WINDOWPOS_CENTERED,
                args.width,
                args.height,
                sdl2.SDL_WINDOW_SHOWN,
            ),
        )
        if not window:
            raise RuntimeError(f"SDL_CreateWindow failed: {sdl2.SDL_GetError().decode()}")
        renderer = setup_stage("create_renderer", lambda: create_renderer(window, args.renderer))
        texture = setup_stage(
            "SDL_CreateTexture",
            lambda: sdl2.SDL_CreateTexture(
                renderer,
                sdl2.SDL_PIXELFORMAT_RGB24,
                sdl2.SDL_TEXTUREACCESS_STREAMING,
                args.width,
                args.height,
            ),
        )
        if not texture:
            raise RuntimeError(f"SDL_CreateTexture failed: {sdl2.SDL_GetError().decode()}")
        print(
            f"window+renderer+texture created ({args.width}x{args.height}), "
            f"video_driver={sdl2.SDL_GetCurrentVideoDriver().decode()} renderer={args.renderer}",
            flush=True,
        )

        event = sdl2.SDL_Event()
        start = time.perf_counter()
        usage_start = resource.getrusage(resource.RUSAGE_SELF)
        processed = 0
        max_faces = 0
        running = True
        frame_times = []
        stage_times = {"capture": 0.0, "inference": 0.0, "annotate_resize": 0.0, "upload": 0.0, "present": 0.0}
        for index in range(args.frames):
            frame_start = time.perf_counter()
            while sdl2.SDL_PollEvent(c.byref(event)):
                if event.type == sdl2.SDL_QUIT:
                    running = False
                if event.type == sdl2.SDL_KEYDOWN and event.key.keysym.sym == sdl2.SDLK_ESCAPE:
                    running = False
            if not running:
                break

            stage_start = time.perf_counter()
            rgb, _info = camera.read(args.frame_timeout)
            stage_times["capture"] += time.perf_counter() - stage_start
            stage_start = time.perf_counter()
            result = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb)))
            stage_times["inference"] += time.perf_counter() - stage_start
            faces = len(result.detections)
            max_faces = max(max_faces, faces)
            processed += 1
            stage_start = time.perf_counter()
            for detection in result.detections:
                box = detection.bounding_box
                cv2.rectangle(
                    rgb,
                    (box.origin_x, box.origin_y),
                    (box.origin_x + box.width, box.origin_y + box.height),
                    (0, 255, 0),
                    4,
                )
                for keypoint in detection.keypoints:
                    cv2.circle(
                        rgb,
                        (int(keypoint.x * rgb.shape[1]), int(keypoint.y * rgb.shape[0])),
                        6,
                        (255, 0, 0),
                        -1,
                    )
            display = np.ascontiguousarray(cv2.resize(rgb, (args.width, args.height)))
            stage_times["annotate_resize"] += time.perf_counter() - stage_start
            stage_start = time.perf_counter()
            if sdl2.SDL_UpdateTexture(texture, None, display.ctypes.data_as(c.c_void_p), args.width * 3) != 0:
                raise RuntimeError(f"SDL_UpdateTexture failed: {sdl_error()}")
            stage_times["upload"] += time.perf_counter() - stage_start
            stage_start = time.perf_counter()
            if sdl2.SDL_RenderClear(renderer) != 0:
                raise RuntimeError(f"SDL_RenderClear failed: {sdl_error()}")
            if sdl2.SDL_RenderCopy(renderer, texture, None, None) != 0:
                raise RuntimeError(f"SDL_RenderCopy failed: {sdl_error()}")
            sdl2.SDL_RenderPresent(renderer)
            stage_times["present"] += time.perf_counter() - stage_start
            frame_times.append(time.perf_counter() - frame_start)
            if index % 30 == 0:
                print(f"  frame {index} faces={faces}", flush=True)

        elapsed = time.perf_counter() - start
        usage_end = resource.getrusage(resource.RUSAGE_SELF)
        cpu_elapsed = (usage_end.ru_utime + usage_end.ru_stime) - (usage_start.ru_utime + usage_start.ru_stime)
        cpu_percent = 100.0 * cpu_elapsed / elapsed if elapsed else 0.0
        fps = processed / elapsed if elapsed else 0.0
        print(
            f"PROCESSED {processed} frames in {elapsed:.3f}s = {fps:.3f} FPS; "
            f"max_faces={max_faces} process_cpu_s={cpu_elapsed:.3f} process_cpu_percent={cpu_percent:.2f}",
            flush=True,
        )
        if processed:
            print(
                "STAGE_AVG_MS "
                + " ".join(f"{name}={seconds * 1000.0 / processed:.3f}" for name, seconds in stage_times.items()),
                flush=True,
            )
            frame_ms = np.asarray(frame_times) * 1000.0
            print(
                f"FRAME_MS avg={frame_ms.mean():.3f} p50={np.percentile(frame_ms, 50):.3f} "
                f"p95={np.percentile(frame_ms, 95):.3f} max={frame_ms.max():.3f}",
                flush=True,
            )
    finally:
        if detector is not None:
            detector.close()
            detector = None
            gc.collect()
        if texture:
            sdl2.SDL_DestroyTexture(texture)
        if renderer:
            sdl2.SDL_DestroyRenderer(renderer)
        if window:
            sdl2.SDL_DestroyWindow(window)
        if sdl_initialized:
            sdl2.SDL_Quit()
        camera.close()
        print("CLEAN EXIT", flush=True)


if __name__ == "__main__":
    main()
