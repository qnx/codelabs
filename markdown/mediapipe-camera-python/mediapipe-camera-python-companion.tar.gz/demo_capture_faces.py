"""Capture QNX camera frames and run MediaPipe face detection."""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import cv2
import mediapipe as mp
import numpy as np
from mediapipe.tasks import python as mpp
from mediapipe.tasks.python import vision

from qnx_camera_helper import QnxCamera


SCRIPT_DIR = Path(__file__).resolve().parent


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be a positive integer")
    return parsed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Capture Camera Module 3 frames, detect faces, and save the final annotated frame."
    )
    parser.add_argument(
        "--model",
        type=Path,
        default=SCRIPT_DIR / "models" / "blaze_face_short_range.tflite",
        help="MediaPipe Face Detector .tflite model",
    )
    parser.add_argument("--frames", type=positive_int, default=120, help="number of frames to process")
    parser.add_argument(
        "--output",
        type=Path,
        default=SCRIPT_DIR / "annotated_face.png",
        help="output path for the final annotated frame",
    )
    parser.add_argument("--camera-unit", type=int, default=3, help="QNX Camera Library unit (default: 3 for QNX 8.0.5 QSTI, CM3 on DISP0)")
    parser.add_argument(
        "--frame-timeout",
        type=float,
        default=2.0,
        help="seconds to wait for each camera frame",
    )
    args = parser.parse_args()
    if args.frame_timeout <= 0:
        parser.error("--frame-timeout must be positive")
    return args


def main() -> None:
    args = parse_args()

    detector = None
    camera = QnxCamera(args.camera_unit)
    try:
        detector = vision.FaceDetector.create_from_options(
            vision.FaceDetectorOptions(
                base_options=mpp.BaseOptions(model_asset_path=str(args.model)),
                min_detection_confidence=0.3,
            )
        )
        camera.open()
        print(f"camera open; running {args.frames} frames", flush=True)

        start = time.time()
        processed = 0
        max_faces = 0
        last = None
        for index in range(args.frames):
            rgb, info = camera.read(args.frame_timeout)
            result = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb)))
            faces = len(result.detections)
            max_faces = max(max_faces, faces)
            processed += 1
            annotated = rgb.copy()
            for detection in result.detections:
                box = detection.bounding_box
                cv2.rectangle(
                    annotated,
                    (box.origin_x, box.origin_y),
                    (box.origin_x + box.width, box.origin_y + box.height),
                    (0, 255, 0),
                    3,
                )
            last = annotated
            if index % 15 == 0:
                print(f"  frame {index} faces={faces} size={info.width}x{info.height}", flush=True)

        elapsed = time.time() - start
        fps = processed / elapsed if elapsed else 0.0
        print(f"PROCESSED {processed} frames in {elapsed:.1f}s = {fps:.1f} FPS; max faces={max_faces}", flush=True)
        if last is not None:
            cv2.imwrite(str(args.output), cv2.cvtColor(last, cv2.COLOR_RGB2BGR))
            print(f"wrote {args.output}", flush=True)
    finally:
        camera.close()
        if detector is not None:
            detector.close()
        print("CLEAN EXIT", flush=True)


if __name__ == "__main__":
    main()
