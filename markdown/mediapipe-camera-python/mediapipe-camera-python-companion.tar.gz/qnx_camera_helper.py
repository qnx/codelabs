"""Reusable QNX libcamapi event-mode camera helper for the MediaPipe codelab."""

from __future__ import annotations

import ctypes as c
import errno
import time
import warnings
from dataclasses import dataclass

import cv2
import numpy as np


u8 = c.c_uint8
u32 = c.c_uint32
i32 = c.c_int32
u64 = c.c_uint64
i64 = c.c_int64

EOK = 0
OPEN_MODE = 1 | 2 | 4 | 16
EVENTMODE_READONLY = 0
FRAMETYPE_NV12 = 1

SIGEV_PULSE = 4
CHF_PRIVATE = 0x1000
SIDE_CHANNEL = 0x40000000
PULSE_CODE_DATA = 1
CLOCK_MONOTONIC = 2
STATE_RECEIVE = 5
NTO_TIMEOUT_RECEIVE = 1 << STATE_RECEIVE
CAMERA_MAX_FRAMEDESC_SIZE = 256
MAX_FRAME_BYTES = 256 * 1024 * 1024
PULSE_RECEIVED = 0
PULSE_TIMED_OUT = 1


class CameraFrameNV12(c.Structure):
    _fields_ = [
        ("height", u32),
        ("width", u32),
        ("stride", u32),
        ("uv_offset", i64),
        ("uv_stride", i64),
    ]


class CameraFrameUnspecified(c.Structure):
    _fields_ = [("framedata", u8 * CAMERA_MAX_FRAMEDESC_SIZE)]


class CameraFrameDesc(c.Union):
    _fields_ = [
        ("unspecified", CameraFrameUnspecified),
        ("nv12", CameraFrameNV12),
    ]


class CameraBuffer(c.Structure):
    _fields_ = [
        ("frametype", c.c_int),
        ("framesize", u64),
        ("framebuf", c.POINTER(u8)),
        ("framemetasize", u64),
        ("framemeta", c.c_void_p),
        ("frametimestamp", i64),
        ("frameorientation", i32),
        ("reserved", u32 * 4),
        ("framedesc", CameraFrameDesc),
    ]


class _SigevUn1(c.Union):
    _fields_ = [("coid", c.c_int), ("ptr", c.c_void_p)]


class _PulseData(c.Structure):
    _fields_ = [("code", c.c_short), ("priority", c.c_short)]


class _SigevUn2(c.Union):
    _fields_ = [("pulse", _PulseData), ("ptr", c.c_void_p)]


class _SigevValue(c.Union):
    _fields_ = [("ival", c.c_int), ("ptr", c.c_void_p)]


class Sigevent(c.Structure):
    _fields_ = [
        ("sigev_notify", c.c_int),
        ("un1", _SigevUn1),
        ("sigev_value", _SigevValue),
        ("un2", _SigevUn2),
    ]


class _Sigval(c.Union):
    _fields_ = [("sival_int", c.c_int), ("sival_ptr", c.c_void_p)]


class Pulse(c.Structure):
    _fields_ = [
        ("type", c.c_uint16),
        ("subtype", c.c_uint16),
        ("code", c.c_int8),
        ("zero", c.c_uint8 * 3),
        ("value", _Sigval),
        ("scoid", c.c_int32),
    ]


def _assert_abi() -> None:
    expected = {
        "CameraFrameNV12.size": (c.sizeof(CameraFrameNV12), 32),
        "CameraFrameNV12.align": (c.alignment(CameraFrameNV12), 8),
        "CameraFrameNV12.height": (CameraFrameNV12.height.offset, 0),
        "CameraFrameNV12.width": (CameraFrameNV12.width.offset, 4),
        "CameraFrameNV12.stride": (CameraFrameNV12.stride.offset, 8),
        "CameraFrameNV12.uv_offset": (CameraFrameNV12.uv_offset.offset, 16),
        "CameraFrameNV12.uv_stride": (CameraFrameNV12.uv_stride.offset, 24),
        "CameraFrameUnspecified.size": (c.sizeof(CameraFrameUnspecified), 256),
        "CameraFrameUnspecified.align": (c.alignment(CameraFrameUnspecified), 1),
        "CameraFrameUnspecified.framedata": (CameraFrameUnspecified.framedata.offset, 0),
        "CameraFrameDesc.size": (c.sizeof(CameraFrameDesc), 256),
        "CameraFrameDesc.align": (c.alignment(CameraFrameDesc), 8),
        "CameraFrameDesc.nv12": (CameraFrameDesc.nv12.offset, 0),
        "CameraBuffer.size": (c.sizeof(CameraBuffer), 328),
        "CameraBuffer.align": (c.alignment(CameraBuffer), 8),
        "CameraBuffer.frametype": (CameraBuffer.frametype.offset, 0),
        "CameraBuffer.framesize": (CameraBuffer.framesize.offset, 8),
        "CameraBuffer.framebuf": (CameraBuffer.framebuf.offset, 16),
        "CameraBuffer.framemetasize": (CameraBuffer.framemetasize.offset, 24),
        "CameraBuffer.framemeta": (CameraBuffer.framemeta.offset, 32),
        "CameraBuffer.frametimestamp": (CameraBuffer.frametimestamp.offset, 40),
        "CameraBuffer.frameorientation": (CameraBuffer.frameorientation.offset, 48),
        "CameraBuffer.reserved": (CameraBuffer.reserved.offset, 52),
        "CameraBuffer.framedesc": (CameraBuffer.framedesc.offset, 72),
        "Pulse.size": (c.sizeof(Pulse), 24),
        "Pulse.align": (c.alignment(Pulse), 8),
        "Pulse.type": (Pulse.type.offset, 0),
        "Pulse.subtype": (Pulse.subtype.offset, 2),
        "Pulse.code": (Pulse.code.offset, 4),
        "Pulse.value": (Pulse.value.offset, 8),
        "Pulse.scoid": (Pulse.scoid.offset, 16),
    }
    bad = [f"{name}: got {got}, expected {want}" for name, (got, want) in expected.items() if got != want]
    if bad:
        raise RuntimeError("QNX camera ctypes ABI mismatch: " + "; ".join(bad))


_assert_abi()


@dataclass
class FrameInfo:
    width: int
    height: int
    stride: int
    uv_offset: int
    uv_stride: int
    timestamp_us: int
    orientation: int


class QnxCamera:
    def __init__(self, unit: int = 1) -> None:
        self.unit = unit
        try:
            self.cam = c.CDLL("libcamapi.so.1")
        except OSError as exc:
            raise RuntimeError(
                "QNX Camera Library libcamapi.so.1 is unavailable; "
                "use a QNX image with the Sensor Framework installed"
            ) from exc
        self.libc = c.CDLL(None, use_errno=True)
        # Target probes validated PyDLL for this adjacent TimerTimeout/receive pair;
        # the equivalent CDLL sequence remained blocked for an unproven reason.
        self.kernel = c.PyDLL(None, use_errno=True)
        self.handle = i32(0)
        self.key = i32(0)
        self.chid = -1
        self.coid = -1
        self._camera_open = False
        self._event_enabled = False
        self._viewfinder_started = False
        self._pulse = Pulse()
        self._buffer = CameraBuffer()
        self._bind_functions()

    def _bind_functions(self) -> None:
        k = self.cam
        l = self.libc
        n = self.kernel

        k.camera_open.restype = c.c_int
        k.camera_open.argtypes = [c.c_int, u32, c.POINTER(i32)]
        k.camera_close.restype = c.c_int
        k.camera_close.argtypes = [i32]
        k.camera_start_viewfinder.restype = c.c_int
        k.camera_start_viewfinder.argtypes = [i32, c.c_void_p, c.c_void_p, c.c_void_p]
        k.camera_stop_viewfinder.restype = c.c_int
        k.camera_stop_viewfinder.argtypes = [i32]
        k.camera_enable_viewfinder_event.restype = c.c_int
        k.camera_enable_viewfinder_event.argtypes = [i32, c.c_int, c.POINTER(i32), c.POINTER(Sigevent)]
        k.camera_disable_event.restype = c.c_int
        k.camera_disable_event.argtypes = [i32, i32]
        k.camera_get_viewfinder_buffers.restype = c.c_int
        k.camera_get_viewfinder_buffers.argtypes = [i32, i32, c.POINTER(CameraBuffer), c.c_void_p]
        k.camera_return_buffer.restype = c.c_int
        k.camera_return_buffer.argtypes = [i32, c.POINTER(CameraBuffer)]

        l.ChannelCreate.restype = c.c_int
        l.ChannelCreate.argtypes = [c.c_uint]
        l.ChannelDestroy.restype = c.c_int
        l.ChannelDestroy.argtypes = [c.c_int]
        l.ConnectAttach.restype = c.c_int
        l.ConnectAttach.argtypes = [u32, c.c_int, c.c_int, c.c_uint, c.c_int]
        l.ConnectDetach.restype = c.c_int
        l.ConnectDetach.argtypes = [c.c_int]

        n.TimerTimeout.restype = c.c_int
        n.TimerTimeout.argtypes = [
            c.c_int,
            u32,
            c.c_void_p,
            c.POINTER(u64),
            c.c_void_p,
        ]
        n.MsgReceivePulse.restype = c.c_int
        n.MsgReceivePulse.argtypes = [c.c_int, c.POINTER(Pulse), c.c_size_t, c.c_void_p]

    def open(self) -> None:
        k = self.cam
        l = self.libc
        try:
            self.chid = l.ChannelCreate(CHF_PRIVATE)
            if self.chid < 0:
                raise RuntimeError("ChannelCreate failed")
            self.coid = l.ConnectAttach(0, 0, self.chid, SIDE_CHANNEL, 0)
            if self.coid < 0:
                raise RuntimeError("ConnectAttach failed")
            if k.camera_open(c.c_int(self.unit), u32(OPEN_MODE), c.byref(self.handle)) != EOK:
                raise RuntimeError("camera_open failed")
            self._camera_open = True

            event = Sigevent()
            event.sigev_notify = SIGEV_PULSE
            event.un1.coid = self.coid
            event.un2.pulse.priority = -1
            event.un2.pulse.code = PULSE_CODE_DATA
            event.sigev_value.ival = 0
            if k.camera_enable_viewfinder_event(
                self.handle, EVENTMODE_READONLY, c.byref(self.key), c.byref(event)
            ) != EOK:
                raise RuntimeError("camera_enable_viewfinder_event failed")
            self._event_enabled = True
            if k.camera_start_viewfinder(self.handle, None, None, None) != EOK:
                raise RuntimeError("camera_start_viewfinder failed")
            self._viewfinder_started = True
        except Exception:
            self.close()
            raise

    @staticmethod
    def _nv12_buffer_size(width: int, height: int, stride: int, uv_offset: int, uv_stride: int) -> int:
        values = {
            "width": width,
            "height": height,
            "stride": stride,
            "uv_offset": uv_offset,
            "uv_stride": uv_stride,
        }
        if width <= 0 or height <= 0 or width % 2 or height % 2:
            raise RuntimeError(f"invalid NV12 frame dimensions: {values}")
        if stride < width or uv_stride < width:
            raise RuntimeError(f"invalid NV12 frame strides: {values}")
        y_size = stride * height
        if uv_offset < y_size:
            raise RuntimeError(f"invalid NV12 UV offset: {values}")
        raw_size = uv_offset + uv_stride * (height // 2)
        if raw_size <= 0 or raw_size > MAX_FRAME_BYTES:
            raise RuntimeError(f"invalid NV12 frame size {raw_size}: {values}")
        return raw_size

    def _receive_pulse_timeout(self, timeout_ns: int) -> int:
        timeout = u64(timeout_ns)
        c.set_errno(0)
        if self.kernel.TimerTimeout(
            CLOCK_MONOTONIC,
            NTO_TIMEOUT_RECEIVE,
            None,
            c.byref(timeout),
            None,
        ) == -1:
            error = c.get_errno()
            raise RuntimeError(
                "TimerTimeout failed with "
                f"{errno.errorcode.get(error, f'errno {error}')}"
            )
        result = self.kernel.MsgReceivePulse(
            self.chid,
            c.byref(self._pulse),
            c.sizeof(self._pulse),
            None,
        )
        if result == -1:
            error = c.get_errno()
            if error == errno.ETIMEDOUT:
                return PULSE_TIMED_OUT
            raise RuntimeError(
                "MsgReceivePulse failed with "
                f"{errno.errorcode.get(error, f'errno {error}')}"
            )
        if result != 0:
            raise RuntimeError(f"MsgReceivePulse returned unexpected rcvid {result}")
        return PULSE_RECEIVED

    def read(self, timeout_seconds: float = 2.0) -> tuple[np.ndarray, FrameInfo]:
        k = self.cam
        if timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")

        deadline = time.monotonic() + timeout_seconds
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(f"camera frame did not arrive within {timeout_seconds:g} seconds")
            receive_result = self._receive_pulse_timeout(
                max(1, int(remaining * 1_000_000_000))
            )
            if receive_result == PULSE_TIMED_OUT:
                raise TimeoutError(f"camera frame did not arrive within {timeout_seconds:g} seconds")
            if receive_result != PULSE_RECEIVED:
                raise RuntimeError(
                    "waiting for a camera frame failed with native error "
                    f"{receive_result}"
                )
            if self._pulse.code != PULSE_CODE_DATA:
                continue
            if k.camera_get_viewfinder_buffers(self.handle, self.key, c.byref(self._buffer), None) != EOK:
                continue

            b = self._buffer
            return_error = EOK
            try:
                if b.frametype != FRAMETYPE_NV12:
                    raise RuntimeError(f"camera returned unsupported frame type {b.frametype}")
                if not b.framebuf:
                    raise RuntimeError("camera returned a null frame buffer")

                desc = b.framedesc.nv12
                info = FrameInfo(
                    width=int(desc.width),
                    height=int(desc.height),
                    stride=int(desc.stride),
                    uv_offset=int(desc.uv_offset),
                    uv_stride=int(desc.uv_stride),
                    timestamp_us=int(b.frametimestamp),
                    orientation=int(b.frameorientation),
                )
                raw_size = self._nv12_buffer_size(
                    info.width,
                    info.height,
                    info.stride,
                    info.uv_offset,
                    info.uv_stride,
                )
                raw = c.string_at(b.framebuf, raw_size)
            finally:
                return_error = k.camera_return_buffer(self.handle, c.byref(b))

            if return_error != EOK:
                raise RuntimeError(f"camera_return_buffer failed with camera error {return_error}")

            data = np.frombuffer(raw, np.uint8)
            y_size = info.stride * info.height
            y_plane = data[:y_size].reshape(info.height, info.stride)[:, : info.width]
            uv_plane = data[info.uv_offset : raw_size].reshape(info.height // 2, info.uv_stride)[:, : info.width]
            uv_plane = uv_plane.reshape(info.height // 2, info.width // 2, 2)
            return cv2.cvtColorTwoPlane(
                np.ascontiguousarray(y_plane),
                np.ascontiguousarray(uv_plane),
                cv2.COLOR_YUV2RGB_NV12,
            ), info

    def close(self) -> None:
        operations = [
            ("camera_stop_viewfinder", self._viewfinder_started, lambda: self.cam.camera_stop_viewfinder(self.handle)),
            ("camera_disable_event", self._event_enabled, lambda: self.cam.camera_disable_event(self.handle, self.key)),
            ("ConnectDetach", self.coid >= 0, lambda: self.libc.ConnectDetach(self.coid)),
            ("ChannelDestroy", self.chid >= 0, lambda: self.libc.ChannelDestroy(self.chid)),
            ("camera_close", self._camera_open, lambda: self.cam.camera_close(self.handle)),
        ]
        failures = []
        for name, active, operation in operations:
            if not active:
                continue
            try:
                result = operation()
                if result != EOK:
                    failures.append(f"{name} returned {result}")
            except Exception as exc:
                failures.append(f"{name} raised {exc!r}")
        self._viewfinder_started = False
        self._event_enabled = False
        self._camera_open = False
        self.coid = -1
        self.chid = -1
        self.handle = i32(0)
        self.key = i32(0)
        if failures:
            warnings.warn("QNX camera cleanup failures: " + "; ".join(failures), RuntimeWarning, stacklevel=2)
