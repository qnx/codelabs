# json-c APK Port - Project Index

Start here for json-c porting work. Read the required reads in order before touching the port.

## Required Reads

1. `json-c-README.md` - current status, the QNX deviations from Alpine, validation results, and the changelog.
2. `qnx-apk-packaging` skill - the shared end-to-end packaging workflow (this port is a clean worked example of it).
3. `aports-patch-creation` skill - before any patch work (the open `test_json_patch` issue would need a patch).

## Key Source Links

- Upstream: https://github.com/json-c/json-c
- Alpine aport (reference): https://gitlab.alpinelinux.org/alpine/aports under `main/json-c` (branch `master`)
- Release tarballs: https://s3.amazonaws.com/json-c_releases/releases/
- QNX aports tree location: `extra/json-c` in `/var/home/qnx/aports_checkin` (new untracked aport, not yet committed/pushed by the human)

## Working Rule

json-c ports almost unchanged from Alpine. The only required QNX deltas are: drop the Doxygen docs and the `-doc` subpackage (doxygen is not packaged on QNX), use `ninja` in place of Alpine's `samurai`, and add `export CFLAGS="$CFLAGS -Qunused-arguments"` so clang does not fail on the default `-fstack-clash-protection` under `-Werror`. The inherited Alpine `cmake-version.patch` is kept because cmake 4.x on QNX needs it. Tests need `checkdepends="diffutils"` (busybox here has no `cmp`). One test, `test_json_patch`, segfaults on a negative array-index case and is selectively skipped pending a source fix; the other 24 pass.

## Status snapshot

- Current version: 0.18 (pkgrel 0)
- Build: passing. APKs produced: `json-c-0.18-r0.apk`, `json-c-dev-0.18-r0.apk`.
- Open blockers: none for packaging. One open defect: `test_json_patch` SIGSEGV (see README), not yet root-caused.
- Last validated: 2026-06-18, x86_64 QNX QEMU target, `abuild -r` exit 0, 24/24 tests pass (1 excluded).

